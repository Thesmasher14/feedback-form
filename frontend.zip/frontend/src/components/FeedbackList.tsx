import React, { useState, useEffect } from 'react';
import './FeedbackList.css';

interface Feedback {
  _id: string;
  name: string;
  email: string;
  feedback?: string;
  message?: string;
  createdAt?: string;
  updatedAt?: string;
  __v?: number;
}

function FeedbackList() {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [error, setError] = useState<string>('');

  const BACKEND_URL = 'http://localhost:5000';

  useEffect(() => {
    fetch(`${BACKEND_URL}/feedback`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    })
      .then((res) => {
        if (!res.ok) throw new Error('Failed to fetch feedback');
        return res.json();
      })
      .then((data) => {
        console.log('Fetched data:', data);
        setFeedbacks(data);
      })
      .catch((err) => {
        console.error('Fetch error:', err);
        setError('❌ Failed to load feedback. Please try again.');
      });
  }, []);

  return (
    <div className="page-wrapper">
      <div className="feedback-list-box">
        <h2>Submitted Feedback</h2>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        {feedbacks.length === 0 && !error && <p>No feedback submitted yet.</p>}
        <div className="feedback-container">
          {feedbacks
            .filter((feedback) => feedback.feedback || feedback.message)
            .map((feedback) => (
              <div key={feedback._id} className="feedback-card">
                <h3>{feedback.name}</h3>
                <p><strong>Email:</strong> {feedback.email}</p>
                <p>
                  <strong>Feedback:</strong>{' '}
                  {feedback.feedback || feedback.message || 'Not provided'}
                </p>
                <p>
                  <strong>Submitted:</strong>{' '}
                  {feedback.createdAt
                    ? new Date(feedback.createdAt).toLocaleString()
                    : 'Not provided'}
                </p>
              </div>
            ))}
        </div>
        <button onClick={() => window.history.back()}>Back to Form</button>
      </div>
    </div>
  );
}

export default FeedbackList;